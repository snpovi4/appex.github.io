// popup.js
document.addEventListener('DOMContentLoaded', function() {
  // Function to retrieve stored credentials
  function getStoredCredentials() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      var tab = tabs[0];
      chrome.storage.local.get(tab.url, function(result) {
        var storedCredentials = result[tab.url];
        if (storedCredentials) {
          document.getElementById('savedUsername').textContent = storedCredentials.username;
          document.getElementById('savedPassword').textContent = "*****";
        } else {
          document.getElementById('savedUsername').textContent = "No saved credentials for this website.";
          document.getElementById('savedPassword').textContent = "";
        }
      });
    });
  }

  // Call getStoredCredentials when the popup is opened
  getStoredCredentials();

  // Event listener for the Save button
  document.getElementById('saveButton').addEventListener('click', function() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    encryptPassword(password, function(encryptedPassword) {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        var tab = tabs[0];
        chrome.storage.local.set({[tab.url]: {username: username, password: encryptedPassword}}, function() {
          console.log('Credentials saved.');
          getStoredCredentials();
        });
      });
    });
  });

  // Function to encrypt password
  function encryptPassword(password, callback) {
    // In a real-world scenario, you'd use a more secure encryption method
    // For demonstration purposes, we're just converting the password to base64
    var encryptedPassword = btoa(password);
    callback(encryptedPassword);
  }
});
