// background.js

// Listen for tab change events
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  // Check if the tab's URL matches a stored credentials
  chrome.storage.local.get(tab.url, function(result) {
    var storedCredentials = result[tab.url];
    if (storedCredentials) {
      // Decrypt credentials before autofilling
      decryptCredentials(storedCredentials, function(decryptedCredentials) {
        // Execute content script to autofill credentials
        chrome.scripting.executeScript({
          target: {tabId: tabId},
          func: autofillCredentials,
          args: [decryptedCredentials.username, decryptedCredentials.password]
        });
      });
    }
  });
});

// Function to decrypt credentials
function decryptCredentials(storedCredentials, callback) {
  decryptPassword(storedCredentials.password, function(decryptedPassword) {
    callback({
      username: storedCredentials.username,
      password: decryptedPassword
    });
  });
}

// Function to decrypt password
function decryptPassword(encryptedPassword, callback) {
  // In a real-world scenario, you'd use the corresponding decryption method
  // For demonstration purposes, we're just converting the Base64 string back to the original password
  var decryptedPassword = atob(encryptedPassword);
  callback(decryptedPassword);
}

// Function to autofill credentials
function autofillCredentials(username, password) {
  var usernameField = document.querySelector('input[type="text"]');
  var passwordField = document.querySelector('input[type="password"]');
  if (usernameField && passwordField) {
    usernameField.value = username;
    passwordField.value = password;
    passwordField.dispatchEvent(new Event('input', { bubbles: true }));
  }
}
